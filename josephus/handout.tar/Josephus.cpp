////////////////////////////////////////////////////////////////////////////////
// Name:
// Date:
// Assignment:
// Description:
//
////////////////////////////////////////////////////////////////////////////////

#include <list>
// TODO: add additional includes

#include "Josephus.h"

/* Simulate the Josephus problem modeled as a std::list.
 * This function will modify the passed list with only a
 * single survivor remaining.
 *
 * @param circle -- the linked list of people
 * @param k -- skip amount. NOTE: k > 0
 *
 * @return a list of those who are executed in chronological order
 */
template <typename T>
std::list<T>
execute (std::list<T>& circle, int k)
{
  std::list<T> killed;
  // TODO :)
  
  return killed;
}

/* entry point to the Josephus problem from the autograder / main
 *
 * @param n -- number of people in the circle
 * @param k -- skip amount. NOTE: k > 0
 */
int
josephus (int n, int k)
{
  // 1. make a list
  // 2. populate it with values [1, 2, 3, ... , N]
  // 3. call execute
  // 4. return the lone survivor

  // HINT: While working on this lab, you may also find
  //       it useful to print out the "kill" order.
  
  return 0;
}
